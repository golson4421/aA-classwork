# == Schema Information
#
# Table name: actors
#
#  id          :integer      not null, primary key
#  name        :string
#
# Table name: movies
#
#  id          :integer      not null, primary key
#  title       :string
#  yr          :integer
#  score       :float
#  votes       :integer
#  director_id :integer
#
# Table name: castings
#
#  movie_id    :integer      not null, primary key
#  actor_id    :integer      not null, primary key
#  ord         :integer

require_relative './sqlzoo.rb'

def example_join
  execute(<<-SQL)
    SELECT
      *
    FROM
      movies
    JOIN
      castings ON movies.id = castings.movie_id
    JOIN
      actors ON castings.actor_id = actors.id
    WHERE
      actors.name = 'Sean Connery'
  SQL
end

def ford_films
  # List the films in which 'Harrison Ford' has appeared.
  execute(<<-SQL)
    SELECT movies.title
    FROM movies
    JOIN castings ON movies.id = castings.movie_id
    JOIN actors ON castings.actor_id = actors.id
    WHERE actors.name = 'Harrison Ford'
  SQL
end

def ford_supporting_films
  # List the films where 'Harrison Ford' has appeared - but not in the star
  # role. [Note: the ord field of casting gives the position of the actor. If
  # ord=1 then this actor is in the starring role]
  execute(<<-SQL)
    SELECT movies.title
    FROM movies
    JOIN castings ON movies.id = castings.movie_id
    JOIN actors ON castings.actor_id = actors.id
    WHERE actors.name = 'Harrison Ford' 
    AND ord <> 1
  SQL
end

def films_and_stars_from_sixty_two
  # List the title and leading star of every 1962 film.
  execute(<<-SQL)
    SELECT title, name
    FROM movies
    JOIN castings ON movies.id = castings.movie_id
    JOIN actors ON castings.actor_id = actors.id
    WHERE movies.yr = 1962
    AND ord = 1
  SQL
end

def travoltas_busiest_years
  # Which were the busiest years for 'John Travolta'? Show the year and the
  # number of movies he made for any year in which he made at least 2 movies.
  execute(<<-SQL)
    SELECT yr, COUNT(movies.*)
    FROM movies
    JOIN castings ON movies.id = castings.movie_id
    RIGHT JOIN actors ON castings.actor_id = actors.id AND actors.name = 'John Travolta'
    GROUP BY 1 
    HAVING COUNT(movies.*) >= 2
  SQL
end

def andrews_films_and_leads
  # List the film title and the leading actor for all of the films 'Julie
  # Andrews' played in.
  execute(<<-SQL)
    SELECT julie_andrews_movies.title, actors.name
    FROM (
      SELECT movies.id, movies.title
      FROM movies
      JOIN castings ON movies.id = castings.movie_id
      JOIN actors ON castings.actor_id = actors.id
      WHERE actors.name = 'Julie Andrews') AS julie_andrews_movies
    LEFT JOIN castings on julie_andrews_movies.id = castings.movie_id AND castings.ord = 1
    LEFT JOIN actors on castings.actor_id = actors.id
  SQL
end

def prolific_actors
  # Obtain a list in alphabetical order of actors who've had at least 15
  # starring roles.
  execute(<<-SQL)
    SELECT actors.name
    FROM actors
    LEFT JOIN castings ON actors.id = castings.actor_id
    GROUP BY actors.name
    HAVING SUM(CASE WHEN ord=1 THEN 1 ELSE 0 END) >= 15
    ORDER BY actors.name
  SQL
end

def films_by_cast_size
  # List the films released in the year 1978 ordered by the number of actors
  # in the cast (descending), then by title (ascending).
  execute(<<-SQL)
    SELECT movies.title, COUNT(castings.actor_id) as num_actors
    FROM movies
    JOIN castings ON movies.id = castings.movie_id
    WHERE movies.yr = 1978
    GROUP BY 1
    ORDER BY 2 DESC, 1 ASC
  SQL
end

def colleagues_of_garfunkel
  # List all the people who have played alongside 'Art Garfunkel'.
  execute(<<-SQL)
    SELECT DISTINCT actors.name 
    FROM actors
    RIGHT JOIN castings ON castings.actor_id = actors.id
    RIGHT JOIN (SELECT castings.movie_id
    FROM castings
    RIGHT JOIN actors ON castings.actor_id = actors.id AND actors.name = 'Art Garfunkel') garfunkel
    ON garfunkel.movie_id = castings.movie_id
    WHERE actors.name <> 'Art Garfunkel'
  SQL
end
